using UnityEngine;

public class RecallNPC : MonoBehaviour
{
    public KeyCode interactKey = KeyCode.E;

    private bool playerInRange = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
        }
    }

    private void Update()
    {
        if (playerInRange && Input.GetKeyDown(interactKey))
        {
            if (QuestionRecallManager.Instance != null)
            {
                QuestionRecallManager.Instance.ShowRecall();
            }
        }
    }
}