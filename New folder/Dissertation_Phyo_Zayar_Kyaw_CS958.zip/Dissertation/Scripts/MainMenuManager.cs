using UnityEngine;

public class MainMenuManager : MonoBehaviour
{
    public GameObject difficultyPanel; 
    public GameObject stageGridPanel;  
    public StageSelectManager stageSelectManager;

    private void Awake()
    {
        stageGridPanel.SetActive(false);
        difficultyPanel.SetActive(true);
    }

    public void SelectEasy()
    {
        EnsureGameManagerExists();
        GameManager.Instance.SetDifficulty(false);
        stageSelectManager.world = 1;
        ShowStageGrid();
    }

    public void SelectHard()
    {
        EnsureGameManagerExists();
        GameManager.Instance.SetDifficulty(true);
        stageSelectManager.world = 2;
        ShowStageGrid();
    }

    private void ShowStageGrid()
    {
        difficultyPanel.SetActive(false);
        stageGridPanel.SetActive(true);
        stageSelectManager.PopulateGrid();
    }

    private void EnsureGameManagerExists()
    {
        if (GameManager.Instance == null)
        {
            GameObject go = new GameObject("GameManager");
            go.AddComponent<GameManager>();
        }
    }

    public void BackToDifficulty()
    {
        stageGridPanel.SetActive(false);
        difficultyPanel.SetActive(true);
    }

    public void QuitGame()
    {
    #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
    #else
        Application.Quit();
    #endif
    }
}