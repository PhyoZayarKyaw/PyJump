using UnityEngine;
using TMPro;

public class QuestionRecallManager : MonoBehaviour
{
    public static QuestionRecallManager Instance { get; private set; }

    [Tooltip("Set this whenever a new question becomes active (e.g. after talking to an NPC).")]
    [TextArea(3, 10)]
    public string currentQuestion = "";

    [SerializeField] private GameObject recallPanel;
    [SerializeField] private TextMeshProUGUI recallText;

    private void Awake()
    {
        Instance = this;
        recallPanel.SetActive(false);
    }

    public void SetCurrentQuestion(string question)
    {
        currentQuestion = question;
    }

    public void ShowRecall()
    {
        recallText.text = string.IsNullOrEmpty(currentQuestion)
            ? "You haven't been asked a question yet."
            : currentQuestion;

        recallPanel.SetActive(true);
    }

    public void HideRecall()
    {
        recallPanel.SetActive(false);
    }
}