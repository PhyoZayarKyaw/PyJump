# PyJump

A 2D platformer that teaches foundational Python programming — **data types**, **conditionals**, and **loops** — through gameplay mechanics that directly embody each concept's logic, rather than isolated coding exercises.

This game was developed as part of an MSc dissertation research project at the University of Strathclyde, investigating whether a serious game can effectively teach programming fundamentals to science students with little to no prior coding experience.

---

## Who this is for

No programming background is required. The game is designed for students studying subjects like mathematics or physics who haven't yet learned to code, and it assumes zero prior Python knowledge going in.

---

## How to Play

### Controls

| Action | Key |
|---|---|
| Move left / right | Arrow keys or `A` / `D` |
| Jump | Spacebar |
| Interact (talk to NPCs) | `E` |
| Pick up / drop carriable object | `TAB` |
| Enter into a pipe downward | 'S' |
| Enter through a pipe to get back up | 'D' |

### Structure

Each concept is taught across a **pair of stages**:

- **Teach Stage** — introduces the concept through guided, low-stakes gameplay with clear instruction and explanation.
- **Test Stage** — immediately checks whether the concept actually landed, with no more explanation, and some additional challenge.

### In-game support

- **Hint button** — shows a plain-language explanation if you're stuck.
- **Instruction recall** — revisit the stage's original code snippet at any time without restarting.
- **Reset button** — cleanly restarts the current stage with no penalty.
- **Stage select** — replay any unlocked stage to improve your star rating.

### Difficulty

Choose **Easy** or **Hard** from the main menu before starting. Easy mode gives you a generous number of lives to experiment freely; Hard Mode provides a greater challenge with limited lives and most of the test stages are altered from those in Easy Mode. Progress and star ratings are tracked separately for each difficulty.

### Stars

Completing a stage can earn up to **three stars**, awarded independently for:
1. Finishing within the time limit of 5 minutes
2. Collecting all available coins
3. Completing the stage without losing a life

---

## System Requirements

- **Windows 10 or 11** (64-bit)
- No specific graphics hardware, controller, or peripheral required beyond a keyboard
- Approx. play time: *[20-30 minutes for a single easy or hard full playthrough]*

---

## Installation & Running the Game

1. Download the provided `.zip` file.
2. Extract **all** contents to a folder on your computer (don't run the `.exe` directly from inside the zip — extract it first).
3. Double-click `PyJump.exe` to launch the game.

### Windows SmartScreen warning (expected — please read)

Because this build isn't signed with a paid code-signing certificate, Windows will likely show a blue screen when you first launch it:

> **"Windows protected your PC"**
> Microsoft Defender SmartScreen prevented an unrecognised app from starting.

This is expected and does **not** mean the file is unsafe — it simply means the app isn't registered with Microsoft. To proceed:

1. Click **"More info"** (a small link on the warning screen — easy to miss).
2. Click the **"Run anyway"** button that appears.

This is a one-time step per copy of the file — once you've run it, Windows won't ask again for that specific `.exe`.

**A note on antivirus software:** some antivirus tools may also flag the `.exe` as suspicious purely because it's unsigned and unfamiliar — this is a common false positive for independently built Unity games and not a sign of an actual problem. If your antivirus blocks the file, you may need to allow it manually or temporarily disable real-time scanning to launch it.

### macOS users

*[Note: this build currently targets Windows only — if a Mac build is provided separately, use the instructions below.]*

Since the build isn't signed with an Apple Developer certificate, macOS will block it on first launch with a "damaged" or "unidentified developer" warning. To run it:

- **Option 1:** Right-click (or Control-click) the app → **Open** → **Open** again in the confirmation dialog. This bypasses Gatekeeper for this specific app.
- **Option 2:** Open Terminal and run:
  ```
  xattr -cr /path/to/PyJump.app
  ```
  Then launch the app normally.

---

## Feedback & Contact

If you run into any technical issues while playing, or have questions about this research, please contact:

**Phyo Zayar Kyaw**
📧 phyo.kyaw.2025@uni.strath.ac.uk
University of Strathclyde

---

## Acknowledgements

Developed using the Unity game engine and TextMeshPro.